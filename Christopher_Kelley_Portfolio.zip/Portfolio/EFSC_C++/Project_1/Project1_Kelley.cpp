#include <iostream> //reference to the standard input and output library 

using namespace std; //name of operations to be used 

int main() //where execution begins 

{

const int MAXNUMS = 6; //maximum number of entries 

int count; //declaring count as the loop counter 

double num, total, average; //declaring variables for computing the average of the inputs 

cout << "\nThis program will ask you to enter " //prompt the user of how many numbers to enter 

<< MAXNUMS << " numbers.\n\n"; //prompt the user of how many numbers to enter 

count = 1; //initialize the loop counter 

total = 0; //initializing the total to compute the average 

while (count <= MAXNUMS) //while the maximum number of numbers hasn't been entered, prompt the user for numbers 

{

cout << "Enter a number: "; //prompt for the current number 

cin >> num; //read the current number

total = total + num; //add the current number to the total 

count++; //increment the current loop count 

}

count--; //decrement count to number of numbers entered 

average = total / count; //compute the average 

cout << "\nThe average of the numbers is " //output the computed average to the user 

<< average << endl; //output the computed average to the user 

return 0; //terminate execution 

}
