#include <iostream> //reference to the standard input and output library 
#include <iomanip> // input/output manipulators

using namespace std; //name of operations to be used 

int main() //where execution begins 

{
	const float TIP16 = .16; //declaring variable TIP16 and assigning it to .16
	const float TIP20 = .20; //declaring variable TIP20 and assigning it to .20
	int numberPeople = 0; //declaring variable numberPeople and assigning it to 0
	float totalAmount = 0; //declaring variable totalAmount and assigning it to 0
	
	cout << "Please enter the number of people sharing the bill: "; //prompt user for number of people sharing the bill 
	cin >> numberPeople; //number of people sharing the bill is inputted 
	//cout << numberPeople << "\n"; 
	
	cout << "Please enter the amount of the bill: "; //prompt user for the amount of the bill 
	cin >> totalAmount; //the amount of the bill is inputted 
	//cout << totalAmount;
	
	float amountPerPerson = totalAmount / numberPeople; //calculate what each person owes without tip 
	
	cout << setiosflags(ios::fixed) << setiosflags(ios::showpoint) << setprecision(2); //round to the nearest cent and put output in monatary format 
	
	cout << "Amount of bill for 16% tip\n"; //display amount of bill for each person with 16 percent tip
	for (int i = 1; i <= numberPeople; i++) //loop calculation of what each person owes with 16 percent tip for number of people entered  
	{
		cout << "Person" << i << " owes $" << amountPerPerson + (amountPerPerson * TIP16) << "\n"; //calculate and display what each person owes with 16 percent tip 
    } 
	
	cout << "\n\nAmount of bill for 20% tip\n"; //display amount of bill for each person with 20 percent tip
	for (int i = 1; i <= numberPeople; i++) //loop calculation of what each person owes with 20 percent tip for number of people entered 
	{
		cout << "Person" << i << " owes $" << amountPerPerson + (amountPerPerson * TIP20) << "\n"; //calculate and display what each person owes with 20 percent tip
    } 
	
	exit(1); //terminate 
}
