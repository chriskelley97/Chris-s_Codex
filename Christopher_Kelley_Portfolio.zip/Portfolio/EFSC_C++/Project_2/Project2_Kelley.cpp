#include <iostream> // standard input/output library 
#include <fstream> // identifier for creating, writing, and reading files
#include <iomanip> // input/output manipulators, handles the data being read from a file as input or data being written into the file as output
using namespace std; // name of operations to be used 


int main() // where execution begins 
{

string filename = "prices.txt"; // put the filename up front

ofstream outFile; // output file stream

outFile.open(filename.c_str()); //open the file for output

if (outFile.fail()) //if failure while trying to open the file
{
  
  cout << "The file was not successfully opened" << endl; //display that operation to open the file failed 

exit(1); //terminate 

}

// set the output file stream formats

outFile << setiosflags(ios::fixed) //manipulating floating point output to never use scientific notation

<< setiosflags(ios::showpoint) //controls if the trailing zeros and decimal point will be output 

<< setprecision(2); //control the number of digits of an ouput stream display of a floating point value 

// send data to the file

outFile << "Mats " << 39.95 << endl //outputting to the file the text: Mats, 39.95

<< "Bulbs " << 3.22 << endl //outputting to the file the text: Bulbs, 3.22

<< "Fuses " << 1.08 << endl; //outputting to the file the text: Fuses, 1.08

outFile.close(); //close the file for output 

cout << "The file " << filename //outputting to the console that the file has been successfully processed

<< " has been successfully written." << endl; //outputting to the console that the file has been successfully processed

return 0; //end execution 
}
