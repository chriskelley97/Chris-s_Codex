#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct Cage
{
    char animalType[1000 + 1];
} cage;

typedef struct Section
{
    struct Cage *cages;
    int numCages;
} section;

int main()
{
    // input from user
    char userInput[50];
    int N = 0;
    int numSections = 0;
    char split[1] = {' '};

    // command from user
    int userCommand;

    /*
     * 1. User enters number of sections
     * 2. Commands are entered by the user
     */

    // first value entered by the user is number of sections
    scanf("%d", &N);
    getchar();

    if (N >= 1 && N <= 100000)
    {
        // declare section array
        numSections = N;
    }
    section sections[numSections];
    bool cagesStatus[numSections]; // if true memory is allocated for cages

    // update status of cages
    for (int i = 0; i < numSections; i++)
    {
        cagesStatus[i] = false;
    }

    while (1)
    {
        fgets(userInput, 50, stdin);
        // userInput[strlen(userInput) - 1] = '\0'; // removes the new line from input string'
        // printf("%s", userInput);
        char *token = strtok(userInput, split); // 1 5 10
        userCommand = atoi(token);              // converts the string into integer
        int userSection;
        int cageNumber;
        // printf("Hi");
        /*        printf("%s", token);
                token = strtok(NULL, " ");
                printf("%s", token)*/
        ;
        switch (userCommand)
        {
        case 1:
            // provides you the section to be worked upon
            token = strtok(NULL, split);
            userSection = atoi(token);

            if (userSection > numSections || userSection < 0)
            {
                break;
            }

            // provides the structure from the array
            token = strtok(NULL, split);
            sections[userSection - 1].numCages = atoi(token);

            // allocate memory for the cages
            if (cagesStatus[userSection - 1])
            {
                // reallocate memory for the cages
                sections[userSection - 1].cages = realloc(sections[userSection - 1].cages, sections[userSection - 1].numCages * sizeof(cage));
                if (sections[userSection - 1].numCages == 0)
                { // if number of cages is 0 then free the memory of cages
                    free(sections[userSection - 1].cages);
                    cagesStatus[userSection - 1] = false; // update the cage status
                }
            }
            else if (sections[userSection - 1].numCages > 0)
            {
                // allocate memory for the cages
                sections[userSection - 1].cages = calloc(sections[userSection - 1].numCages, sizeof(cage));

                // updates the status of the section and cages for further use
                cagesStatus[userSection - 1] = true;
            }
            break;
        case 2:
            // provides you the section to be worked upon
            token = strtok(NULL, split);
            userSection = atoi(token);

            if (userSection > numSections || userSection < 0)
            {
                break;
            }

            // provides the cage number to be updated with the animal name
            token = strtok(NULL, split);
            cageNumber = atoi(token);

            if (cageNumber > sections[userSection - 1].numCages || cageNumber < 0)
            {
                break;
            }

            // getting animal name
            token = strtok(NULL, split);

            // copying the animal name into the structure cage of the particular section
            if (strlen(sections[userSection - 1].cages[cageNumber - 1].animalType) == 0)
            {
                strcpy(sections[userSection - 1].cages[cageNumber - 1].animalType, token);
            }

            break;
        case 3:
            // provides you the section to be worked upon
            token = strtok(NULL, split);
            userSection = atoi(token);

            if (userSection > numSections || userSection < 0)
            {
                printf("No animal found\n");
                break;
            }

            // provides the structure from the array
            token = strtok(NULL, split);
            cageNumber = atoi(token);

            if (cageNumber > sections[userSection - 1].numCages || cageNumber < 0)
            {
                printf("No animal found\n");
                break;
            }

            // printing the animal name
            if (strlen(sections[userSection - 1].cages[cageNumber - 1].animalType) == 0)
            {
                printf("No animal found\n");
            }
            else
            {
                printf("%s", sections[userSection - 1].cages[cageNumber - 1].animalType);
            }
            break;
        case 4:
            // free the memory
            for (int i = 0; i < numSections; i++)
            {
                if (cagesStatus[i])
                {
                    free(sections[i].cages);
                }
            }
            exit(0);
        default:
            printf("Invalid command");
            break;
        }
    }
}