#include <stdio.h>
#include <stdbool.h>

int main() {
    int arr[] = {1, 2, 3, 10, 21, 33};

    int userVal = 0;
    bool flag = true;

    printf("Enter the number to be searched: ");
    scanf("%d", &userVal);

    // linear search
    // search from beginning to end step by step
    for (int i = 0; i < sizeof arr/sizeof(arr[0]); i++) {
        if (arr[i] == userVal) {
            printf("User value found at index %d\n", i);
            flag = false;
            break;
        }
    }

    // if value is not found
    if(flag){
        printf("User value not found\n");
    }


    return 0;
}