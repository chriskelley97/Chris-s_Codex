#ifndef SORT_BUBBLESORT_H
#define SORT_BUBBLESORT_H
void bubbleSortAscending(int[], int);
void bubbleSortDescending(int[], int);
void swap(int*, int*);
#endif //SORT_BUBBLESORT_H