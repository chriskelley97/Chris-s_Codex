#include <stdio.h>
#include "List.h"
#include <stdlib.h>
#include <ctype.h>


// function declarations
void displayList(list);

void menu();


int main() {
    list list;
    int numOfElements;

    // create a list with initialize size
    create(&list, 0);

    // add an element to the list
    printf("How many elements do you want to add to the list?\n");
    scanf("%d", &numOfElements);


    // initial variable input from user
    for (int i = 0; i < numOfElements; i++) {
        int val;
        printf("Enter the value: ");
        scanf("%d", &val);
        insert(&list, val);
    }

    displayList(list);

    list.size = insertAtValue(list, 1, 345);

    printf("The size of the structure in main is %d\n", list.size);

    displayList(list);


    while (true) {
        int choice;
        int element;
        int position;
        char temp[100];
        char *ptr;
        menu();
        printf("Enter the choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the element: ");
                scanf("%s", temp);
                element = strtol(temp, &ptr, 10);
                insert(&list, element);
                printf("Element is added");
               /* if(isdigit((char)element)){
                    insert(&list, element);
                    printf("Element is added");
                }else {
                    printf("Element is not added");
                }*/
                break;
            case 2:
                printf("Enter the element: ");
                scanf("%d", &element);
                printf("Enter the position: ");
                scanf("%d", &position);
                insertAt(&list, position, element);
                break;
            case 3:
                printf("Enter the element: ");
                scanf("%d", &element);
                position = getIndexByValue(&list, element);
                if(position == -1){
                    printf("Element not found");
                }else{
                    removeAt(&list, position);
                    printf("Element is removed");
                }
                break;
            case 4:
                printf("Enter the element: ");
                scanf("%d", &element);
                position = getIndexByValue(&list, element);
                if(position == -1){
                    printf("Element not found");
                }else{
                    printf("Element found at %d position within the list", position + 1);
                }
                break;
            case 5:
                printf("Enter the element: ");
                scanf("%d", &element);
                position = getIndexByValue(&list, element);
                if(position == -1){
                    printf("Element not found");
                }else{
                    printf("Please enter the new value: ");
                    scanf("%d", &element);
                    replaceAt(&list, position, element);
                    printf("The value is replaced");
                }
                break;
            case 6:
                displayList(list);
                break;
            case 7:
                printf("Thank you for your contribution.\n");
                exit(0);
            default:
                printf("Invalid choice");
                break;
        }
    }

}


void displayList(list v) {
    printf("\nTotal number of elements: %d\n", v.size);
    for (int i = 0; i < v.size; i++) {
        int val = get(&v, i);
        printf("%d ", val);
    }
}


void menu() {
    printf("1. Add an element\n");
    printf("2. Add at position\n");
    printf("3. Remove an element\n");
    printf("4. Search an element\n");
    printf("5. Replace an element\n");
    printf("6. Display the list\n");
    printf("7. Exit\n");
}