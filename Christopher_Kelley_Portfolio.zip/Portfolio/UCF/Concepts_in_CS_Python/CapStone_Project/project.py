#Christopher Kelley
#project.py
#Helps Small Monster Collectors find tournament participates and winner
#Wrote it to help Small Monster Collectors view past tournament data
#Small Monster Collectors were having trouble organizing and finding certain tournament data
#This program inputs text file data of past tournaments, then formats and displays the desired tournament data   

import sys

#Evaluates the text file lines and organizes the information
#Parameter is the file stream
def ReadFileByLine(file):
    table = []
    header = ""
    info = ""
    index = 0

    while (line := file.readline()):
        if index == 0:
            info = line
        elif index == 2:
            header = line
        else:
            table.append(line)
        index += 1
    return info, header, table

#Validates the user's input
#Parameters are the string prompt, minimum value, and maximum value
def ValidateUserIntegerInput(prompt,rangeMin,rangeMax):
    userInput = int(input(prompt))
    if userInput > rangeMax or userInput < rangeMin:
        raise ValueError()
    return userInput

#Main
#Open file and display error if file does not exist 
try:
    file = open("battle_data.txt", "r")
except FileNotFoundError:
    sys.exit("File does not exist")
#Execute the file input function and returns a list representation of the input
t_info, t_header, t_List = ReadFileByLine(file)
file.close()
print("Hi! Welcome to Small Monster Tournament results! Here are last year's results.")
#Replace comma with new line in first line of text file for user-friendly display of info
res_info = t_info.replace(",","\n")
print(res_info)
userInput = None
#Keep prompting user for tournament number until user enters 0
while userInput != 0:
#Execute validate user input function 
    try:
        userInput = ValidateUserIntegerInput("Enter a Tournament number to see the results or enter 0 to exit:",0,len(t_List)-1)
    except ValueError:
        userInput = -1
        print("Invalid Tournament Number")
#if user does not enter -1,format and display user inputted tournament 
    if userInput != -1 and userInput != 0:
        res_header = t_header.replace("\n","").split(",")
        res_t = t_List[userInput].replace("\n","").split(",")
        res_zip = zip(res_header,res_t)
        for header_item,tourny_item in res_zip:
            print(header_item,tourny_item)
