def drawGrid(hm, hc, vm, vc, c):
    r = hm * hc + vm * vc + c
    return r

hm = float(input("What is the horizontal multiplier?"))
hc = range(10)
vm = float(input("What is the vertical multiplier?"))
vc = range(8)
c = float(input("What is the constant?"))
    
import turtle
t = turtle.Turtle()
t.fillcolor("yellow")
t.speed(0)
for hc in range(10):
    for vc in range(8):
        t.goto(25 * hc, -25 * vc)
        t.pendown()
        t.begin_fill()
        t.circle((hm * hc) + (vm * vc) + c)
        t.end_fill()
        t.penup()
drawGrid(hm, hc, vm, vc, c)
