#Christopher Kelley
#vehicle.py
#Drawing a sketch of my Small Monster Collector vehicle
#Help me travel to regions to collect Small Monsters

#import turtle library 
import turtle 

#get screen and turtle, make screen white and turtle black,
#turtle draw at pensize 4 
my_screen = turtle.getscreen()
my_screen.bgcolor("white")
my_turtle = turtle.Turtle()

my_turtle.pensize(4)
my_turtle.color("black")


#Body of truck
my_turtle.fillcolor("blue")
my_turtle.begin_fill()

my_turtle.forward(300)
my_turtle.left(90)
my_turtle.forward(100)
my_turtle.left(90)
my_turtle.forward(300)
my_turtle.left(90)
my_turtle.forward(100)
my_turtle.left(90)

my_turtle.end_fill()

#Cab of truck
my_turtle.fillcolor("yellow")
my_turtle.begin_fill()

my_turtle.forward(-60)
my_turtle.left(-90)
my_turtle.forward(-60)
my_turtle.left(-90)
my_turtle.forward(-60)
my_turtle.left(-90)
my_turtle.forward(-60)
my_turtle.left(-90)

my_turtle.end_fill()

#Wheels of truck
my_turtle.fillcolor("black")
my_turtle.begin_fill()

#first wheel 
my_turtle.penup()
my_turtle.goto(25,0)
my_turtle.pendown()
my_turtle.circle(-30)

#second wheel 
my_turtle.penup()
my_turtle.goto(270,0)
my_turtle.pendown()
my_turtle.circle(-30)

my_turtle.end_fill()

#window of cab
my_turtle.fillcolor("white")
my_turtle.begin_fill()

my_turtle.penup()
my_turtle.goto(-10,25)
my_turtle.pendown()
my_turtle.forward(-30)
my_turtle.left(-90)
my_turtle.forward(-30)
my_turtle.left(-90)
my_turtle.forward(-30)
my_turtle.left(-90)
my_turtle.forward(-30)
my_turtle.left(-90)

my_turtle.end_fill()

