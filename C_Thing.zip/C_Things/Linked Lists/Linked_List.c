#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int data;
    struct node *next;
} node;

int main() {
    // create a head
    node *head = NULL;


    // allocate the memory to the head
    head = malloc(sizeof(node));

    printf("Enter the data: ");
    scanf("%d", &head->data); // allocating data to head because there is no node
    head->next = NULL;

    printf("Please let me know how many values to enter: ");
    int n;
    scanf("%d", &n);


    for(int i = 0; i < n; i++){
        // create a temporary node
        node *temp = malloc(sizeof(node));
        printf("Enter the data: ");
        scanf("%d", &temp->data);
        temp->next = NULL;

        // if the next of head is null attach the new node to it
        if(head == NULL){
            head = temp;
        }else if(head->next == NULL) {
            head->next = temp;
           // temp->next = head;
        }else{
            node *traverse = head; // temporary node to traverse the list
            // go until you reach the last node in the list
            // as the last node next points to null
            while(traverse->next != NULL){
                traverse = traverse->next;
            }

            // attach the new node to the last node
            traverse->next = temp;
            // temp->next = head; circular linked list
        }
    }


    // print the list
    node *traverse = head;
    while(traverse != NULL){
        printf("%d ", traverse->data);
        traverse = traverse->next;
    }

    // finding a value
    printf("Enter the value to find: ");
    int value;
    scanf("%d", &value);

    traverse = head;
    // go till the end of the list
    while(traverse != NULL){
        if(traverse->data == value){
            printf("Found the value %d", value);
            break;
        }
        traverse = traverse->next;
    }

    if(traverse == NULL){
        printf("Value not found");
    }


    // remove the value
    printf("Enter the value to remove: ");
    scanf("%d", &value);

    traverse = head;
    node *previous = NULL;
    node *ahead = NULL;

    while(traverse != NULL){
        if(head->data == value) {
            head = head->next;
            free(traverse);
            break;
        }else if(traverse->next->data == value){
            previous = traverse; // previous node to the node to be removed
            ahead = traverse->next->next; // node after the node to be removed
            previous->next = ahead; // attach the previous node to the node after the node to be removed'
            traverse = traverse->next; // traverse to the node to be removed
            free(traverse); // free the node
            break;
        }
        traverse = traverse->next;
    }


    if(traverse == NULL){
        printf("Value not found");
    }


    // print the list
    traverse = head;
    while(traverse != NULL){
        printf("%d ", traverse->data);
        traverse = traverse->next;
    }

    return 0;
}