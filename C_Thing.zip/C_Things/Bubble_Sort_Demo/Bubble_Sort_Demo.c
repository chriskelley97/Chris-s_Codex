#include "BubbleSort.h"


void bubbleSortAscending(int *arr, int size){
    int outerLoop, innerLoop;
    for(outerLoop = 0; outerLoop < size - 1; outerLoop++){
        for(innerLoop = 0; innerLoop < size - 1; innerLoop++){
            if(arr[innerLoop] > arr[innerLoop + 1]){
                swap(&arr[innerLoop], &arr[innerLoop + 1]);
            }
        }
    }
}

void bubbleSortDescending(int *arr, int size){
    int outerLoop, innerLoop;
    for(outerLoop = 0; outerLoop < size - 1; outerLoop++){
        for(innerLoop = 0; innerLoop < size - 1; innerLoop++){
            if(arr[innerLoop] < arr[innerLoop + 1]){
                swap(&arr[innerLoop], &arr[innerLoop + 1]);
            }
        }
    }
}

void swap(int *oldVal, int *newVal){
    int temp = *oldVal;
    *oldVal = *newVal;
    *newVal = temp;
}