// This program calculates your age in the year 2050.
// Input:  None
// Output: Your current age followed by your age in 2050

#include <iostream>
using namespace std;
int main()
{
   // Declare and initialize your variables here
   int myNewAge;
   int myCurrentAge;
   int currentYear = 2021;
   
		
   cout << "Enter age: ";
   cin >> myCurrentAge;
   myNewAge = myCurrentAge + (2050 - currentYear);
   cout << "I will be " << myNewAge << " in 2050." << endl;

   return 0;
}
