#include <iostream>
using namespace std;

int main()
{
int count;

count = 1; // initialize count
while (count <= 10);
{
cout << count << " ";
count++; // increment count
}

return 0;
}
